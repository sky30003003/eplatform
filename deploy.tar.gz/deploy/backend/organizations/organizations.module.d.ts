export declare class OrganizationsModule {
}
