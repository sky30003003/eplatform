export declare class CreateOrganizationDto {
    name: string;
    email: string;
    phone: string;
    companyCode: string;
    avatarUrl?: string;
}
