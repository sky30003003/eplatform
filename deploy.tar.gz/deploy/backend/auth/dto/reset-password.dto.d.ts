export declare class ResetPasswordDto {
    token: string;
    newPassword: string;
}
