export declare class RefreshTokenDto {
    refreshToken: string;
}
