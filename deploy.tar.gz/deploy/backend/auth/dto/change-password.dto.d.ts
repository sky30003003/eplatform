export declare class ChangePasswordDto {
    newPassword: string;
}
