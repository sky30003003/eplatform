export declare class RequestPasswordResetDto {
    email: string;
}
