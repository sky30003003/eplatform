import { DataSource } from 'typeorm';
declare const _default: DataSource;
export default _default;
